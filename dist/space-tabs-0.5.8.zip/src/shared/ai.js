import {
  providerById,
  providerForBaseUrl,
  providerRequiresApiKey,
  providerSupportsThinking,
} from './ai-providers.js';
import { assertSafeAIAuthTransport } from './ai-auth.js';

export const AI_OUTPUT_TOKEN_BUDGETS = Object.freeze({
  'tidy-names': Object.freeze({ small: 8_192, medium: 16_384, large: 32_768 }),
  'auto-group': Object.freeze({ small: 16_384, medium: 32_768, large: 65_536 }),
  'test-ai': 1_024,
});

export function outputTokenBudgetForPurpose(purpose, itemCount) {
  const normalized = String(purpose || '').trim();
  if (!Object.hasOwn(AI_OUTPUT_TOKEN_BUDGETS, normalized)) {
    throw new Error(`Unsupported AI purpose: ${normalized || 'missing'}.`);
  }
  const budget = AI_OUTPUT_TOKEN_BUDGETS[normalized];
  if (typeof budget === 'number') return budget;

  const count = Number(itemCount);
  if (!Number.isInteger(count) || count < 0) {
    throw new Error(`${normalized} AI requests require a non-negative integer itemCount.`);
  }
  if (count <= 80) return budget.small;
  if (count <= 200) return budget.medium;
  return budget.large;
}

export function normalizeBaseUrl(baseUrl) {
  const trimmed = String(baseUrl || '').trim().replace(/\/+$/, '');
  return trimmed.replace(/\/chat\/completions$/, '');
}

export function getOriginPattern(baseUrl) {
  const url = new URL(normalizeBaseUrl(baseUrl));
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw new Error('AI Base URL must use http or https.');
  }
  return `${url.protocol}//${url.hostname}/*`;
}

export function buildChatCompletionRequest(settings, messages, purpose, itemCount) {
  assertSafeAIAuthTransport(settings);
  const baseUrl = normalizeBaseUrl(settings.baseUrl);
  const headers = {
    'Content-Type': 'application/json',
  };
  const apiKey = String(settings.apiKey || '').trim();
  if (apiKey && providerRequiresApiKey(settings)) headers.Authorization = `Bearer ${apiKey}`;
  const body = {
    model: settings.model,
    messages,
    stream: false,
  };
  const outputTokenBudget = outputTokenBudgetForPurpose(purpose, itemCount);

  if (usesOpenAIChatParameters(settings)) {
    body.max_completion_tokens = outputTokenBudget;
    if (supportsNoReasoningEffort(settings.model)) body.reasoning_effort = 'none';
  } else {
    const temperature = Number(settings.temperature ?? 0.6);
    body.temperature = Number.isFinite(temperature) ? temperature : 0.6;
    body.max_tokens = outputTokenBudget;
  }

  if (providerSupportsThinking(settings)) {
    body.thinking = {
      type: settings.thinking === 'enabled' ? 'enabled' : 'disabled',
    };
  }

  return {
    url: `${baseUrl}/chat/completions`,
    method: 'POST',
    headers,
    body,
  };
}

function usesOpenAIChatParameters(settings = {}) {
  const provider = settings?.provider
    ? providerById(settings.provider)
    : providerForBaseUrl(settings?.baseUrl);
  return provider?.id === 'openai';
}

function supportsNoReasoningEffort(model) {
  return /^gpt-5\.(?:[1-9]\d*)(?:-|$)/.test(String(model || '').trim().toLowerCase());
}

export function extractAssistantText(payload) {
  const choice = payload?.choices?.[0];
  return choice?.message?.content || choice?.delta?.content || '';
}

export function extractFinishReason(payload) {
  return payload?.choices?.[0]?.finish_reason || null;
}

export function parseChatStreamEvent(line) {
  const value = String(line || '').trim();
  if (!value.startsWith('data:')) return null;
  const data = value.slice(5).trim();
  if (!data) return null;
  if (data === '[DONE]') {
    return { done: true, text: '', usage: null, finishReason: null };
  }
  try {
    const payload = JSON.parse(data);
    return {
      done: false,
      text: extractAssistantText(payload),
      usage: payload.usage || null,
      finishReason: extractFinishReason(payload),
    };
  } catch {
    return null;
  }
}

export function languageInstruction(language) {
  const normalized = String(language || '').trim() || 'auto';
  if (normalized === 'zh-CN') return 'Respond in Simplified Chinese.';
  if (normalized === 'en') return 'Respond in English.';
  if (normalized === 'auto') return 'Respond in the same language as the user question or the page content.';
  return `Respond in ${normalized}.`;
}

export function formatAIError(error) {
  const message = String(error?.message || error || '').trim();
  if (error?.name === 'AbortError') return 'AI request was stopped.';
  if (/^AI provider rejected the request \(HTTP \d+/i.test(message)) return message;
  if (/api key is missing|missing api key|add it in settings/i.test(message)) {
    return 'AI API key is missing. Add it in Settings.';
  }
  if (/insufficient|balance|quota|余额不足|账户余额/i.test(message)) {
    return 'AI provider rejected the request: insufficient balance. Update the BYOK account or API key in Settings.';
  }
  if (/401|403|unauthorized|forbidden|api key|invalid key/i.test(message)) {
    return 'AI provider rejected the request: check the BYOK API key and model settings.';
  }
  return message || 'AI request failed.';
}

export function createPrompt(kind, context = {}) {
  const instruction = languageInstruction(context.language || 'auto');
  if (kind === 'tidy-tabs') {
    const ruleText = String(context.rules || '').trim();
    return [
      {
        role: 'system',
        content: [
          ...(ruleText ? [ruleText] : []),
          'Include every supplied tab id exactly once; do not omit tabs, invent ids, or repeat ids.',
          'Return only JSON: [{"title":"Topic","tabIds":[1,2],"color":"blue"}].',
        ].join(' '),
      },
      {
        role: 'user',
        content: JSON.stringify(context.tabs || []),
      },
    ];
  }

  if (kind === 'tidy-names') {
    const ruleText = String(context.rules || '').trim();
    return [
      {
        role: 'system',
        content: [
          ...(ruleText ? [ruleText] : []),
          'Rename only the tabs supplied in the input; do not invent ids or include tabs that are not present.',
          'Return only JSON: [{"id":1,"title":"Concise Name"}].',
          instruction,
        ].join(' '),
      },
      {
        role: 'user',
        content: JSON.stringify(context.tabs || []),
      },
    ];
  }

  if (kind === 'custom') {
    return [
      {
        role: 'system',
        content: `You are an AI assistant embedded in a browser tab sidebar. Keep answers concise and useful. ${instruction}`,
      },
      {
        role: 'user',
        content: context.prompt || '',
      },
    ];
  }

  throw new Error(`Unsupported AI prompt kind: ${String(kind || 'missing')}.`);
}

export function buildListModelsRequest(settings) {
  assertSafeAIAuthTransport(settings);
  const headers = {
    'Content-Type': 'application/json',
  };
  const apiKey = String(settings.apiKey || '').trim();
  if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
  return {
    url: `${normalizeBaseUrl(settings.baseUrl)}/models`,
    method: 'GET',
    headers,
  };
}

export function parseModelsResponse(payload) {
  const entries = Array.isArray(payload?.data) ? payload.data : [];
  return [...new Set(entries
    .map((item) => String(item?.id || '').trim())
    .filter(Boolean))].sort((left, right) => left.localeCompare(right));
}

export function parseTidyGroups(text) {
  try {
    const parsed = parseJsonArray(text);
    return parsed
      .map((group) => ({
        // Keep the provider's logical Tag name intact. Chrome's physical
        // 32-character representation is an output concern handled when the
        // group is written, not part of saved organization identity.
        title: String(group?.title || 'Tabs').replace(/\s+/g, ' ').trim() || 'Tabs',
        color: normalizeGroupColor(group?.color),
        tabIds: Array.isArray(group?.tabIds)
          ? group.tabIds.map((id) => Number(id)).filter(Number.isFinite)
          : [],
      }))
      .filter((group) => group.tabIds.length > 0);
  } catch {
    return [];
  }
}

export function parseTidyNames(text, tabs = []) {
  try {
    const allowedIds = new Set((tabs || []).map((tab) => Number(tab.id)).filter(Number.isFinite));
    const parsed = parseJsonArray(text);
    const names = {};
    for (const item of parsed) {
      const id = Number(item?.id ?? item?.tabId);
      if (!Number.isFinite(id)) continue;
      if (allowedIds.size > 0 && !allowedIds.has(id)) continue;
      const title = cleanTidyName(item?.title ?? item?.name ?? item?.displayTitle);
      if (!title || Object.hasOwn(names, id)) continue;
      names[id] = title;
    }
    return names;
  } catch {
    return {};
  }
}

function parseJsonArray(text) {
  const value = String(text || '').trim();
  const candidates = [
    value,
    fencedJson(value),
    bracketedJsonArray(value),
  ].filter(Boolean);

  for (const candidate of candidates) {
    try {
      const parsed = JSON.parse(candidate);
      if (Array.isArray(parsed)) return parsed;
    } catch {
      // Try the next likely JSON array shape.
    }
  }
  return [];
}

function fencedJson(value) {
  const match = value.match(/```(?:json)?\s*([\s\S]*?)```/i);
  return match?.[1]?.trim() || '';
}

function bracketedJsonArray(value) {
  const start = value.indexOf('[');
  if (start < 0) return '';

  let depth = 0;
  let quote = '';
  let escaped = false;
  for (let index = start; index < value.length; index += 1) {
    const char = value[index];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (quote) {
      if (char === '\\') escaped = true;
      else if (char === quote) quote = '';
      continue;
    }
    if (char === '"' || char === "'") {
      quote = char;
      continue;
    }
    if (char === '[') depth += 1;
    if (char === ']') {
      depth -= 1;
      if (depth === 0) return value.slice(start, index + 1);
    }
  }
  return '';
}

function normalizeGroupColor(color) {
  const allowed = new Set(['grey', 'blue', 'red', 'yellow', 'green', 'pink', 'purple', 'cyan', 'orange']);
  const normalized = String(color || '').trim().toLowerCase();
  return allowed.has(normalized) ? normalized : 'blue';
}

function cleanTidyName(value) {
  const text = String(value || '')
    .replace(/[\u200b-\u200d\ufeff]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  return text.length > 64 ? `${text.slice(0, 61)}...` : text;
}
